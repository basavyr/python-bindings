
#include <Python.h>
#include <chrono>
#include <ctime>
#include <iostream>
#include <string>

static PyObject *pants(PyObject *self, PyObject *args)
{
    int input;
    if (!PyArg_ParseTuple(args, "i", &input))
    {
        return NULL;
    }
    return PyLong_FromLong((long)input * (long)input);
}

static PyObject *pants2(PyObject *self, PyObject *args)
{
    int i = 69;
    int y = 72;
    PyObject *result = Py_BuildValue("i", i);
    return result;
}

static PyObject *pants3(PyObject *self)
{
    auto now = std::chrono::system_clock::now();
    std::time_t date = std::chrono::system_clock::to_time_t(now);
    auto retval = std::ctime(&date);
    PyObject *result = Py_BuildValue("s", retval);
    return result;
}

static PyObject *showname(PyObject *self, PyObject *args)
{
    std::string name;
    std::time_t date = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    auto retval = std::ctime(&date);
    if (!PyArg_ParseTuple(args, "s", &name))
    {
        return NULL;
    }
    PyObject *result = NULL;
    auto f1 = name + " " + retval;
    result = Py_BuildValue("s", f1);
    return result;
}

static PyMethodDef example_methods[] = {
    {"pants2", pants2, METH_VARARGS, "Returns a number"},
    {"pants", pants, METH_VARARGS, "Returns a square of an integer"},
    {"pants3", (PyCFunction)pants3, METH_NOARGS, "Returns a good number"},
    {"showname", showname, METH_VARARGS, "Returns date and user on screen"},
    {NULL, NULL, 0, NULL},
};

static struct PyModuleDef example_definition = {
    PyModuleDef_HEAD_INIT,
    "example",
    "example module containing pants() function",
    -1,
    example_methods,
};

PyMODINIT_FUNC PyInit_example(void)
{
    Py_Initialize();
    PyObject *m = PyModule_Create(&example_definition);

    return m;
}