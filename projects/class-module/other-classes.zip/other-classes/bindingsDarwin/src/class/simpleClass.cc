#include <Python.h>
#include <structmember.h>
#include <string>
#include <chrono>
#include <ctime>
#include <vector>
typedef struct
{
    PyObject_HEAD // no semicolon
        int number;
    char letter;
    std::string name;
} Typer;

static void Typer_dealloc(Typer *self)
{
    Py_TYPE(self)->tp_free((PyObject *)self);
}

static PyObject *Typer_new(PyTypeObject *type, PyObject *args,
                           PyObject *kwds)
{
    Typer *self;

    self = (Typer *)type->tp_alloc(type, 0);
    if (self != NULL)
    {
        self->number = 0;
        self->name = " ";
        self->letter = ' ';
    }

    return (PyObject *)self;
}

static int Typer_init(Typer *self, PyObject *args, PyObject *kwds)
{
    std::string init = "nameX";
    self->number = 1;
    self->letter = 'a';
    self->name = init.c_str();
    return 0;
}

static PyMemberDef Typer_members[] = {
    {"number", T_INT, offsetof(Typer, number), 0, "Typer number"},
    {"letter", T_CHAR, offsetof(Typer, letter), 0, "Typer letter"},
    {"name", T_STRING, offsetof(Typer, name), 0, "Typer name"},
    {NULL} /* Sentinel */
};

static PyObject *Typer_miami(Typer *self)
{
    if (self->number > 1)
        self->number /= 2;

    return PyLong_FromLong((long)self->number);
}

static PyObject *Typer_new_york(Typer *self)
{
    if (self->number < 1024 * 1024)
        self->number *= 2;

    return PyLong_FromLong((long)self->number);
}

static PyObject *Typer_showclass(Typer *self)
{
    PyObject *retval = NULL;
    const char *namestring;
    const char *let;
    let = &self->letter;
    namestring = self->name.c_str();
    retval = Py_BuildValue("(i,s,s)", self->number, let, namestring);
    return retval;
}

static PyObject *Typer_datenow(Typer *self, PyObject *args)
{
    const char *name;
    // std::string name;
    if (!PyArg_ParseTuple(args, "s", &name))
    {
        return NULL;
    }
    std::time_t date = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    auto retval = std::ctime(&date);
    PyObject *result = NULL;
    auto f1 = std::string(name) + " " + retval;
    result = Py_BuildValue("s", f1.c_str());
    return result;
}

static PyObject *Typer_vectorToList(Typer *self, const std::vector<float> &arrdata)
{
    PyObject *listObject = PyList_New(arrdata.size());
    if (!listObject)
        return nullptr;
    for (size_t index = 0; index < arrdata.size(); ++index)
    {
        PyObject *element = PyFloat_FromDouble(arrdata[index]);
        if (!element)
        {
            Py_DECREF(listObject);
            return nullptr;
        }
        PyList_SET_ITEM(listObject, index, element);
    }
    return listObject;
}

//get C array from a python tuple object
static PyObject *Typer_getarrayfromtuple(Typer *self, PyObject *args)
{
    PyObject *retval;
    PyObject *tuple;

    //parse python objects to C variables
    if (!PyArg_ParseTuple(args, "O!", &PyTuple_Type, &tuple))
        return NULL;

    //allocate emory for C array
    double *arr =
        arr = (double *)malloc(sizeof(double) * PyTuple_GET_SIZE(tuple));
    int length;
    length = PyTuple_GET_SIZE(tuple);
    PyObject *item = NULL;
    //populate the array
    for (int i = 0; i < length; ++i)
    {
        item = PyTuple_GET_ITEM(tuple, i);
        arr[i] = PyFloat_AsDouble(item);
        if (arr[i] == -1. && PyErr_Occurred())
        {
            exit(1);
        }
    }

    //compute the sum of the elements
    double result = 0.0;
    for (int i = 0; i < length; ++i)
    {
        result += arr[i];
    }
    retval = PyFloat_FromDouble(result);
    free(arr);
    return retval;
}

//get C array from a python list object
static PyObject *Typer_getarrayfromlist(Typer *self, PyObject *args)
{
    PyObject *retval;
    PyListObject *list;

    if (!PyArg_ParseTuple(args, "O!", &PyList_Type, &list))
        return NULL;

    //allocate memory for C array
    double *arr =
        arr = (double *)malloc(sizeof(double) * PyList_GET_SIZE(list));
    int size;
    size = PyList_GET_SIZE(list);
    PyObject *listItem = NULL;
    for (int i = 0; i < size; ++i)
    {
        listItem = PyList_GET_ITEM(list, i);
        arr[i] = PyFloat_AsDouble(listItem);
        if (arr[i] == -1. && PyErr_Occurred())
        {
            exit(1);
        }
    }
    retval = PyFloat_FromDouble(arr[0]*arr[2]);
    return retval;
}


static PyMethodDef Typer_methods[] = {
    {"miami", (PyCFunction)Typer_miami, METH_NOARGS, "Divides number by 2"},
    {"new_york", (PyCFunction)Typer_new_york, METH_NOARGS, "Doubles number"},
    {"showclass", (PyCFunction)Typer_showclass, METH_NOARGS, "Shows the class objects"},
    {"datenow", (PyCFunction)Typer_datenow, METH_VARARGS, "Shows the date with custom name"},
    {"vectortolist", (PyCFunction)Typer_vectorToList, METH_VARARGS, "Shows an array or any python object"},
    {"getarrayfromtuple", (PyCFunction)Typer_getarrayfromtuple, METH_VARARGS, "Computes the sum of an array. Converts python tuple to C array."},
    {"getarrayfromlist", (PyCFunction)Typer_getarrayfromlist, METH_VARARGS, "Computes the sum of an array. Converts python list to C array."},
    {NULL} /* Sentinel */
};

static PyTypeObject TyperType = {
    PyVarObject_HEAD_INIT(NULL, 0) "example.Typer", /* tp_name */
    sizeof(Typer),                                  /* tp_basicsize */
    0,                                              /* tp_itemsize */
    (destructor)Typer_dealloc,                      /* tp_dealloc */
    0,                                              /* tp_print */
    0,                                              /* tp_getattr */
    0,                                              /* tp_setattr */
    0,                                              /* tp_reserved */
    0,                                              /* tp_repr */
    0,                                              /* tp_as_number */
    0,                                              /* tp_as_sequence */
    0,                                              /* tp_as_mapping */
    0,                                              /* tp_hash  */
    0,                                              /* tp_call */
    0,                                              /* tp_str */
    0,                                              /* tp_getattro */
    0,                                              /* tp_setattro */
    0,                                              /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE,       /* tp_flags */
    "Typer objects",                                /* tp_doc */
    0,                                              /* tp_traverse */
    0,                                              /* tp_clear */
    0,                                              /* tp_richcompare */
    0,                                              /* tp_weaklistoffset */
    0,                                              /* tp_iter */
    0,                                              /* tp_iternext */
    Typer_methods,                                  /* tp_methods */
    Typer_members,                                  /* tp_members */
    0,                                              /* tp_getset */
    0,                                              /* tp_base */
    0,                                              /* tp_dict */
    0,                                              /* tp_descr_get */
    0,                                              /* tp_descr_set */
    0,                                              /* tp_dictoffset */
    (initproc)Typer_init,                           /* tp_init */
    0,                                              /* tp_alloc */
    Typer_new,                                      /* tp_new */
};

static struct PyModuleDef example_definition = {
    PyModuleDef_HEAD_INIT,
    "example",
    "example module containing Typer class",
    -1,
    NULL,
};

PyMODINIT_FUNC PyInit_example(void)
{
    Py_Initialize();
    PyObject *m = PyModule_Create(&example_definition);

    if (PyType_Ready(&TyperType) < 0)
        return NULL;

    Py_INCREF(&TyperType);
    PyModule_AddObject(m, "Typer", (PyObject *)&TyperType);

    return m;
}