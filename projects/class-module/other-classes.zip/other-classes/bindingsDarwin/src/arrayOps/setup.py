from distutils.core import setup, Extension

example_module = Extension(
    'arrayops',
    sources=['arrayops.cc'],
    libraries=['pthread'],
    extra_compile_args=["-std=c++14"],
    language='C++', )

setup(
    name='arrayops',
    version='0.1.0',
    description='example module written in C++',
    ext_modules=[example_module], )
