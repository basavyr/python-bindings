#include "arrayops.hh"

namespace ARRAYOPERATIONS
{
//SHOW VALUES
PyObject *ArrayOps::ArrayOps_showclass(ArrayOps *self)
{
    PyObject *retval = NULL;

    //build the list object for python
    PyObject *array;
    array = PyList_New(static_cast<Py_ssize_t>(self->size));
    PyObject *inserter = NULL;
    for (int i = 0; i < self->size; ++i)
    {
        auto currentvalue = self->arr[i];
        inserter = Py_BuildValue("d", static_cast<double>(currentvalue));
        Py_ssize_t index = static_cast<int>(i);
        PyList_SetItem(array, index, inserter);
    }

    retval = Py_BuildValue("(i,i,O)", self->number, self->size, array);
    return retval;
}

//generate array from init function
PyObject *ArrayOps::ArrayOps_createlist(ArrayOps *self)
{
    // PyListObject *list;
    PyObject *list;

    //set list size
    Py_ssize_t listsize;
    listsize = static_cast<int>(self->size);

    //create the list
    list = PyList_New(listsize);

    //add items to list
    PyObject *inserter = NULL;
    for (int i = 0; i < self->size; ++i)
    {
        auto currentval = (self->arr[i]) - i;
        inserter = Py_BuildValue("d", static_cast<double>(currentval));
        Py_ssize_t index = static_cast<int>(i);
        PyList_SetItem(list, index, inserter);
    }

    //return the list to python
    PyObject *retval = NULL;
    retval = Py_BuildValue("O", list);
    return retval;
}

} // namespace ARRAYOPERATIONS