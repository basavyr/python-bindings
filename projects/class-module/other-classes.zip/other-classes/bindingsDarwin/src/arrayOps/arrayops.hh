#include <Python.h>
#include <structmember.h>

namespace ARRAYOPERATIONS
{
class ArrayOps
{
    //methods
public:
    static PyObject *ArrayOps_showclass(ArrayOps *self);
    static PyObject *ArrayOps_createlist(ArrayOps *self);

    //variables
public:
    PyObject_HEAD double number;
    int size;
    double *arr;
};
//THE DEALLOC PROCEDURE
static void ArrayOps_dealloc(ArrayOps *self)
{
    Py_TYPE(self)->tp_free((PyObject *)self);
}

//THE NEW IMPLEMENTATION
static PyObject *ArrayOps_new(PyTypeObject *type, PyObject *args,
                              PyObject *kwds)
{
    ArrayOps *self;

    self = (ArrayOps *)type->tp_alloc(type, 0);
    if (self != NULL)
    {
        self->number = 0;
        self->size = 0;
        self->arr = nullptr;
    }
    return (PyObject *)self;
}

//THE INIT IMPLEMENATION
static int ArrayOps_init(ArrayOps *self, PyObject *args, PyObject *kwds)
{
    double initNumber;
    int sizeOfArray;
    if (!PyArg_ParseTuple(args, "di", &initNumber, &sizeOfArray))
    {
        return NULL;
    }
    self->number = initNumber;
    self->size = static_cast<size_t>(sizeOfArray);
    self->arr = (double *)malloc(sizeof(double) * self->size);
    for (int i = 0; i < self->size; ++i)
    {
        self->arr[i] = initNumber;
    }
    return 0;
}

//class variables
static PyMemberDef ArrayOps_members[] = {
    {"number", T_INT, offsetof(ArrayOps, number), 0, "ArrayOps number variable type."},
    {"size", T_INT, offsetof(ArrayOps, size), 0, "ArrayOps size of array variable type."},
    {"array", T_OBJECT, offsetof(ArrayOps, arr), 0, "ArrayOps array variable type."},
    {NULL} /* Sentinel */
};

static PyMethodDef ArrayOps_methods[] = {
    {"showclass", (PyCFunction)ARRAYOPERATIONS::ArrayOps::ArrayOps_showclass, METH_NOARGS, "Returns the init number."},
    {"createlist", (PyCFunction)ARRAYOPERATIONS::ArrayOps::ArrayOps_createlist, METH_NOARGS, "Returns a C++ generated list."},
    {NULL} /* Sentinel */
};

static PyTypeObject ArrayOpsType = {
    PyVarObject_HEAD_INIT(NULL, 0) "arrayops.ArrayOps", /* tp_name */
    sizeof(ArrayOps),                                   /* tp_basicsize */
    0,                                                  /* tp_itemsize */
    (destructor)ArrayOps_dealloc,                       /* tp_dealloc */
    0,                                                  /* tp_print */
    0,                                                  /* tp_getattr */
    0,                                                  /* tp_setattr */
    0,                                                  /* tp_reserved */
    0,                                                  /* tp_repr */
    0,                                                  /* tp_as_number */
    0,                                                  /* tp_as_sequence */
    0,                                                  /* tp_as_mapping */
    0,                                                  /* tp_hash  */
    0,                                                  /* tp_call */
    0,                                                  /* tp_str */
    0,                                                  /* tp_getattro */
    0,                                                  /* tp_setattro */
    0,                                                  /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE,           /* tp_flags */
    "ArrayOps objects",                                 /* tp_doc */
    0,                                                  /* tp_traverse */
    0,                                                  /* tp_clear */
    0,                                                  /* tp_richcompare */
    0,                                                  /* tp_weaklistoffset */
    0,                                                  /* tp_iter */
    0,                                                  /* tp_iternext */
    ArrayOps_methods,                                   /* tp_methods */
    ArrayOps_members,                                   /* tp_members */
    0,                                                  /* tp_getset */
    0,                                                  /* tp_base */
    0,                                                  /* tp_dict */
    0,                                                  /* tp_descr_get */
    0,                                                  /* tp_descr_set */
    0,                                                  /* tp_dictoffset */
    (initproc)ArrayOps_init,                            /* tp_init */
    0,                                                  /* tp_alloc */
    ArrayOps_new,                                       /* tp_new */
};

static struct PyModuleDef arrayops_definition = {
    PyModuleDef_HEAD_INIT,
    "arrayops",
    "arrayops module containing ArrayOps C++ class",
    -1,
    NULL,
};

PyMODINIT_FUNC PyInit_arrayops(void)
{
    Py_Initialize();
    PyObject *m = PyModule_Create(&arrayops_definition);

    if (PyType_Ready(&ArrayOpsType) < 0)
        return NULL;

    Py_INCREF(&ArrayOpsType);
    PyModule_AddObject(m, "ArrayOps", (PyObject *)&ArrayOpsType);

    return m;
}

} // namespace ARRAYOPERATIONS
