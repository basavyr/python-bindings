import bindingsbasavyr as x

name=[1,2,3,1,2,3,1,2,3,1,2,3,1,2,3,1,2,3,1,2,3,1,2,3]
y=x.BindingsBasavyr(name,60)

# print(y.number)
# print(y.name)
print(y.nyc()) 
print(y.islist())
print(y.getsecondelement())