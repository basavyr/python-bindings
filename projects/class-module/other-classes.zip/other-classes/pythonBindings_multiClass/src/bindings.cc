#include "bindings.hh"

static PyObject *miami(BindingsBasavyr *self)
{
    if (self->number > 1)
        self->number /= 2;

    return PyLong_FromLong((long)self->number);
}

static PyObject *newyork(BindingsBasavyr *self)
{
    if (self->number < 100)
        self->number *= 2;

    return PyLong_FromLong((long)self->number);
}

static PyObject *islist(BindingsBasavyr *self)
{
    bool condition = false;
    if (PyList_Check(self->name))
        condition = true;
    PyObject *result = NULL;
    char *islist = "IT IS OK";
    char *isnotlist = "IT IS NOT OK";
    if (condition)
        result = Py_BuildValue("s", islist);
    else
    {
        result = Py_BuildValue("s", isnotlist);
    }
    return result;
}

static PyObject *getsecondelement(BindingsBasavyr *self)
{
    PyObject *result = NULL;
    if (PyList_Check(self->name))
    {
        Py_ssize_t listsize = PyList_Size(self->name) - 1;
        PyObject *data = PyList_New(listsize);
        for (Py_ssize_t i = 0; i < listsize; ++i)
        {
            PyObject *value = PyList_GetItem(self->name, i);
            PyList_SetItem(data, i, value);
            // Py_XDECREF(value);
        }
        result = data;
        // Py_XDECREF(data);
    }
    return result;
}
