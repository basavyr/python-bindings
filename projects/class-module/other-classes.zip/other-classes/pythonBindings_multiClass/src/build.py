from distutils.core import setup, Extension

example_module = Extension(
    'bindingsbasavyr',
    sources=['bindings.cc'],
    language='C++', )

setup(
    name='bindingsbasavyr',
    version='0.1.0',
    description='bindingsbasavyr module written in C++',
    ext_modules=[example_module], )
