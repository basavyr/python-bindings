#!/usr/bin/python
import simplefunction
print(simplefunction.simplefunction())
