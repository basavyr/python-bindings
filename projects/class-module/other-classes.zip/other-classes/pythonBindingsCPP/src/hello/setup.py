from distutils.core import setup, Extension

module1 = Extension('hello', include_dirs=[
                    '/usr/include'], libraries=['pthread'], sources=['hello.c'])

setup(name='hello', version='1.0', description='Simple tutorial',
      url='http://www.elk.nipne.ro', ext_modules=[module1])
