from distutils.core import setup, Extension
setup(name="noddy", version="1.0",
      ext_modules=[
          Extension("Special2", include_dirs=[
              '/usr/include'], libraries=['pthread'], extra_compile_args=[], sources=['extendedType.cc']),
      ])
