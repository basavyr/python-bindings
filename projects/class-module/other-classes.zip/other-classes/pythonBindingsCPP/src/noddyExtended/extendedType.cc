#include <Python.h>
#include "structmember.h"

namespace extendedType
{
class ExtendedType
{
public:
    static PyObject *testFunction(PyObject *self, PyObject *args);
};

PyObject *ExtendedType::testFunction(PyObject *self, PyObject *args)
{
    static const char *stringg[] = {"Hey"};
    PyObject *result = Py_BuildValue("s", stringg);
}

typedef struct
{
    PyObject_HEAD
        PyObject *first; /* first name */
    PyObject *last;      /* last name */
    int number;
} Special;

static void
Special_dealloc(Special *self)
{
    Py_XDECREF(self->first);
    Py_XDECREF(self->last);
    Py_TYPE(self)->tp_free((PyObject *)self);
}

static PyObject *
Special_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
    Special *self;

    self = (Special *)type->tp_alloc(type, 0);
    if (self != NULL)
    {
        self->first = PyUnicode_FromString("");
        if (self->first == NULL)
        {
            Py_DECREF(self);
            return NULL;
        }

        self->last = PyUnicode_FromString("");
        if (self->last == NULL)
        {
            Py_DECREF(self);
            return NULL;
        }

        self->number = 0;
    }

    return (PyObject *)self;
}

static int
Special_init(Special *self, PyObject *args, PyObject *kwds)
{
    PyObject *first = NULL, *last = NULL, *tmp;

    static char *kwlist[] = {"first", "last", "number", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwds, "|OOi", kwlist,
                                     &first, &last,
                                     &self->number))
        return -1;

    if (first)
    {
        tmp = self->first;
        Py_INCREF(first);
        self->first = first;
        Py_XDECREF(tmp);
    }

    if (last)
    {
        tmp = self->last;
        Py_INCREF(last);
        self->last = last;
        Py_XDECREF(tmp);
    }
    return 0;
}

static PyMemberDef Special_members[] = {
    {"first", T_OBJECT_EX, offsetof(Special, first), 0,
     "first name"},
    {"last", T_OBJECT_EX, offsetof(Special, last), 0,
     "last name"},
    {"number", T_INT, offsetof(Special, number), 0,
     "Special number"},
    {NULL} /* Sentinel */
};

static PyObject *
Special_name(Special *self)
{
    if (self->first == NULL)
    {
        PyErr_SetString(PyExc_AttributeError, "first");
        return NULL;
    }

    if (self->last == NULL)
    {
        PyErr_SetString(PyExc_AttributeError, "last");
        return NULL;
    }

    return PyUnicode_FromFormat("%S %S", self->first, self->last);
}

static PyMethodDef Special_methods[] = {
    {"name", (PyCFunction)Special_name, METH_NOARGS,
     "Return the name, combining the first and last name"},
    {NULL} /* Sentinel */
};

static PyTypeObject SpecialType = {
    PyVarObject_HEAD_INIT(NULL, 0) "special.Special", /* tp_name */
    sizeof(Special),                                  /* tp_basicsize */
    0,                                                /* tp_itemsize */
    (destructor)Special_dealloc,                      /* tp_dealloc */
    0,                                                /* tp_print */
    0,                                                /* tp_getattr */
    0,                                                /* tp_setattr */
    0,                                                /* tp_reserved */
    0,                                                /* tp_repr */
    0,                                                /* tp_as_number */
    0,                                                /* tp_as_sequence */
    0,                                                /* tp_as_mapping */
    0,                                                /* tp_hash  */
    0,                                                /* tp_call */
    0,                                                /* tp_str */
    0,                                                /* tp_getattro */
    0,                                                /* tp_setattro */
    0,                                                /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT |
        Py_TPFLAGS_BASETYPE, /* tp_flags */
    "Special objects",       /* tp_doc */
    0,                       /* tp_traverse */
    0,                       /* tp_clear */
    0,                       /* tp_richcompare */
    0,                       /* tp_weaklistoffset */
    0,                       /* tp_iter */
    0,                       /* tp_iternext */
    Special_methods,         /* tp_methods */
    Special_members,         /* tp_members */
    0,                       /* tp_getset */
    0,                       /* tp_base */
    0,                       /* tp_dict */
    0,                       /* tp_descr_get */
    0,                       /* tp_descr_set */
    0,                       /* tp_dictoffset */
    (initproc)Special_init,  /* tp_init */
    0,                       /* tp_alloc */
    Special_new,             /* tp_new */
};



static PyModuleDef Special2module = {
    PyModuleDef_HEAD_INIT,
    "Special2",
    "Example    module that creates an extension type.",
    -1,
    NULL, NULL, NULL, NULL, NULL};

PyMODINIT_FUNC
PyInit_Special2(void)
{
    PyObject *m;

    if (PyType_Ready(&SpecialType) < 0)
        return NULL;

    m = PyModule_Create(&Special2module);
    if (m == NULL)
        return NULL;

    Py_INCREF(&SpecialType);
    PyModule_AddObject(m, "Special", (PyObject *)&SpecialType);
    return m;
}
} // namespace extendedType