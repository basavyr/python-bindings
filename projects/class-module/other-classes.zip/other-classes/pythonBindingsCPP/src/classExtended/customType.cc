#include "customType.hh"
#include <string>

namespace CustomTypeNS
{
PyObject *CustomType::show(PyObject *self)
{
    /* static const char *text;
    if (!PyArg_ParseTuple(args, "s", &text))
        return NULL; */
    std::string sname = "hey";
    PyObject *results = Py_BuildValue("s", sname.c_str());
    return results;
}

} // namespace CustomTypeNS