from distutils.core import setup, Extension
setup(name="customtype", version="1.0",
      ext_modules=[
          Extension("customtype", include_dirs=[
              '/usr/include'], libraries=['pthread'], extra_compile_args=[], sources=['customType.cc']),
      ])
