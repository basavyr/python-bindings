#ifndef CUSTOMTYPE_HH
#define CUSTOMTYPE_HH

#if PY_MAJOR_VERSION >= 3
#define PY3K
#endif

#include "PyXRootD.hh"

namespace CustomTypeNS
{
class CustomType
{
private:
    /* data */
public:
    static PyObject *show(PyObject *self);

public:
    PyObject_HEAD
        PyObject *firstArgument;
    int number;
};

//INIT function
static int
CustomType_init(CustomType *self, PyObject *args)
{
    PyObject *first = NULL, *tmp;

    if (!PyArg_ParseTuple(args, "si", &first,
                          &self->number))
        return -1;

    if (first)
    {
        tmp = self->firstArgument;
        Py_INCREF(first);
        self->firstArgument = first;
        Py_XDECREF(tmp);
    }
    return 0;
}

// deallocation function
static void
CustomType_dealloc(CustomType *self)
{
    delete self->firstArgument;
    Py_TYPE(self)->tp_free((PyObject *)self);
}

static PyMethodDef CustomType_methods[] =
    {
        {"show",
         (PyCFunction)CustomTypeNS::CustomType::show, METH_VARARGS, NULL},
        {NULL} /* Sentinel */
};

static PyMemberDef CustomType_members[] =
    {
        {NULL} /* Sentinel */
};

#ifdef PY3K
// module definition structure for python3
static struct PyModuleDef CustomTypemodule = {
    PyModuleDef_HEAD_INIT,
    "customtype",
    "Example module that creates an extension type.",
    -1,
    CustomType_methods, NULL, NULL, NULL, NULL};
// module initializer for python3
PyMODINIT_FUNC PyInit_CustomType(void)
{
    Py_Initialize();
    return PyModule_Create(&CustomTypemodule);
}

#else
// module initializer for python2
PyMODINIT_FUNC initCustomType()
{
    Py_InitModule3("customtype", CustomType_methods, "mod doc");
}
#endif

//----------------------------------------------------------------------------
//! File binding type object
//----------------------------------------------------------------------------
static PyTypeObject CustomTypeType = {
    PyVarObject_HEAD_INIT(NULL, 0) "customtype.CustomType",          /* tp_name */
    sizeof(CustomType),                                              /* tp_basicsize */
    0,                                                               /* tp_itemsize */
    (destructor)CustomType_dealloc,                                  /* tp_dealloc */
    0,                                                               /* tp_print */
    0,                                                               /* tp_getattr */
    0,                                                               /* tp_setattr */
    0,                                                               /* tp_compare */
    0,                                                               /* tp_repr */
    0,                                                               /* tp_as_number */
    0,                                                               /* tp_as_sequence */
    0,                                                               /* tp_as_mapping */
    0,                                                               /* tp_hash */
    0,                                                               /* tp_call */
    0,                                                               /* tp_str */
    0,                                                               /* tp_getattro */
    0,                                                               /* tp_setattro */
    0,                                                               /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE | Py_TPFLAGS_HAVE_ITER, /* tp_flags */
    "doc for custom type",                                           /* tp_doc */
    0,                                                               /* tp_traverse */
    0,                                                               /* tp_clear */
    0,                                                               /* tp_richcompare */
    0,                                                               /* tp_weaklistoffset */
    0,                                                               /* tp_iter */
    0,                                                               /* tp_iternext */
    CustomType_methods,                                              /* tp_methods */
    CustomType_members,                                              /* tp_members */
    0,                                                               /* tp_getset */
    0,                                                               /* tp_base */
    0,                                                               /* tp_dict */
    0,                                                               /* tp_descr_get */
    0,                                                               /* tp_descr_set */
    0,                                                               /* tp_dictoffset */
    (initproc)CustomType_init,                                       /* tp_init */
};

} // namespace CustomTypeNS

#endif // CUSTOMTYPE_HH
