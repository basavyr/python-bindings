#!/usr/bin/env python3
# encoding: utf-8

from distutils.core import setup, Extension

info_module = Extension(
    'info',
    sources=['info.cc'],
    language='C++', )

setup(
    name='info',
    version='0.1.0',
    description='info module written in C++',
    ext_modules=[info_module], )
