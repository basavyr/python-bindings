from distutils.core import setup, Extension

module1 = Extension('simplefunction', include_dirs=[
                    '/usr/include'], libraries=['pthread'], extra_compile_args=['-std=c++11'], sources=['main.cc'])

setup(name='simplefunction', version='1.0', description='Simple function with arguments',
      url='http://www.elk.nipne.ro', ext_modules=[module1])
