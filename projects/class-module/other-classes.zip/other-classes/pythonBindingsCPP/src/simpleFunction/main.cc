#include <Python.h>
#include <string>
#include <ctime>
#include <chrono>

#if PY_MAJOR_VERSION >= 3
#define PY3K
#endif

//declaring a function with (multiple) arguments to be used in python
static PyObject *functionWithArgs(PyObject *self, PyObject *args);

//declaring a function with (multiple) arguments and keywords to be used in python
static PyObject *functionWithKeywords(PyObject *self, PyObject *args, PyObject *kwds);
//declaring a function without any arguments to be used in python
static PyObject *functionWithNoArgs(PyObject *self);

//THEORETICAL CONCEPTS
/* 
static PyObject *module_func(PyObject *self, PyObject *args)
{
    //some stuff
    int number = 0;
    Py_RETURN_NONE;
}
 */
/* 
struct PyMethodDef
{
    //name of the c function as the python interpreter presents when it is used in python programs
    char *moduleName;

    //the address to a function that has any of the signatures described in the examples above
    PyCFunction moduleMethod;

    //tell the interpreter which of the three types of function signatures to be used
    int moduleFlags;

    //docstring for the module function
    char *moduleDoc;
};
 */

// module functions
static PyObject *simplefunction(PyObject *self, PyObject *args)
{
    char *fromPython, result[1024];
    if (!PyArg_ParseTuple(args, "s", &fromPython))
    {
        return NULL;
    }
    else
    {
        strcpy(result, "Hello, ");
        strcat(result, fromPython);
        return Py_BuildValue("s", result);
    }
}
static PyObject *showdate(PyObject *self, PyObject *args)
{
    const char *name; //variable from python
    int number;       //variable from python

    if (!PyArg_ParseTuple(args, "si", &name, &number))
        return NULL;
    std::string sname;
    std::time_t currentTime = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    sname = "Hey there, " + std::string(name) + " , it's " + (std::string)std::ctime(&currentTime);
    PyObject *result = Py_BuildValue("(si)", sname.c_str(), number);
    return result;
}

static PyObject *measuretime(PyObject *self, PyObject *args)
{
    static long numberFromPython;
    static long numberFromPython2;
    if (!PyArg_ParseTuple(args, "ll", &numberFromPython, &numberFromPython2))
        return NULL;
    auto startTime = std::chrono::high_resolution_clock::now();
    auto sum = 0;
    for (int i = 0; i < numberFromPython; ++i)
    {
        sum += numberFromPython2;
    }
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime).count();
    const char response[] = "Time needed for the for loop to complete in seconds:";
    PyObject *result = Py_BuildValue("sdd", response, (double)duration / 1000.0, (double)sum);
    return result;
}

//documentation of the function
static const char moduleDocs[] = "A simple function: simpleFunction(self, args) | use any arguments you want!\n";
/* 
// module functions
static PyObject *message(PyObject *self, PyObject *args)
{
    char *fromPython, result[1024];
    if (!PyArg_ParseTuple(args, "s", &fromPython))
    {
        return NULL;
    }
    else
    {
        strcpy(result, "Hello, ");
        strcat(result, fromPython);
        return Py_BuildValue("s", result);
    }
} */

// registration table
static PyMethodDef simplefunction_methods[] = {
    {"simplefunction", simplefunction, METH_VARARGS, "moduleDocs"},
    {"showdate", showdate, METH_VARARGS, "moduleDocs"},
    {"measuretime", measuretime, METH_VARARGS, "moduleDocs"},
    {NULL, NULL, 0, NULL}};

#ifdef PY3K
// module definition structure for python3
static struct PyModuleDef simplefunction_module = {
    PyModuleDef_HEAD_INIT,
    "simplefunction",
    "moduleDocs",
    -1,
    simplefunction_methods};
// module initializer for python3
PyMODINIT_FUNC PyInit_simplefunction()
{
    return PyModule_Create(&simplefunction_module);
}
#else
// module initializer for python2
PyMODINIT_FUNC initsimplefunction()
{
    Py_InitModule3("simplefunction", simplefunction_methods, "moduleDocs");
}
#endif
