from distutils.core import setup, Extension

module1 = Extension('noddy', include_dirs=[
                    '/usr/include'], libraries=['pthread'], extra_compile_args=[], sources=['noddyModule.cc'])

setup(name='noddy', version='1.0', description='Simple function with arguments',
      url='http://www.elk.nipne.ro', ext_modules=[module1])
